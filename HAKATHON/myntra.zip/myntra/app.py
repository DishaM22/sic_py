from flask import Flask, request, jsonify, render_template, redirect, url_for
import os
import pandas as pd
from flask_cors import CORS
from werkzeug.utils import secure_filename
from collections import Counter

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


@app.route('/')
def home():
    return render_template('home.html')  # Separate landing page


@app.route('/dashboard')
def dashboard():
    return render_template('index.html')  # Main dashboard page


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if file and file.filename.endswith('.csv'):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        # Load dataset
        df = pd.read_csv(file_path)

        # Analysis 1: Basic stats
        total_products = len(df)
        avg_price = round(df['price'].mean(), 2) if 'price' in df else 0
        avg_rating = round(df['avg_rating'].mean(), 1) if 'avg_rating' in df else 0
        total_brands = df['brand'].nunique() if 'brand' in df else 0
        top_brands = df['brand'].value_counts().nlargest(10).to_dict() if 'brand' in df else {}
        categories = df['products'].value_counts().nlargest(8).to_dict() if 'products' in df else {}

        # Analysis 2: Fabric types
        fabric_keywords = ['cotton', 'rayon', 'nylon', 'polyester', 'denim', 'silk', 'linen', 'chiffon', 'viscose', 'lycra']
        fabric_counter = Counter()
        if 'p_attributes' in df:
            for val in df['p_attributes'].dropna():
                text = str(val).lower()
                for fabric in fabric_keywords:
                    if fabric in text:
                        fabric_counter[fabric] += 1
        fabric_analysis = dict(fabric_counter.most_common(8))

        # Analysis 3: Product-Colour combinations
        if 'products' in df and 'colour' in df:
            combo_counts = df.groupby(['products', 'colour']).size().reset_index(name='count')
            top_combos = combo_counts.sort_values(by='count', ascending=False).head(10)
            top_combinations = top_combos.to_dict(orient='records')
        else:
            top_combinations = []

        # Analysis 4: Top colours
        colour_analysis = df['colour'].value_counts().nlargest(8).to_dict() if 'colour' in df else {}

        insights = {
            'totalProducts': total_products,
            'avgPrice': avg_price,
            'avgRating': avg_rating,
            'totalBrands': total_brands,
            'topBrands': top_brands,
            'categories': categories,
            'fabricAnalysis': fabric_analysis,
            'colourAnalysis': colour_analysis,
            'topCombinations': top_combinations
        }

        return jsonify({'message': 'File uploaded successfully!', 'insights': insights})

    return jsonify({'error': 'Invalid file format. Only CSV allowed'}), 400


if __name__ == '__main__':
    app.run(debug=True)
